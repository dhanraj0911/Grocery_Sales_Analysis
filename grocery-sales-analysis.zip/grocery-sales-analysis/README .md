# 🛒 Grocery Sales Analysis using Python

This project analyzes grocery sales data to uncover insights related to top-selling products, customer behavior, profit margins, and more. Built using Python and Jupyter Notebook, it walks through the full cycle of data analysis: data cleaning, merging, feature engineering, visualization, and business interpretation.

---

## 📌 Objective

- Understand and analyze sales patterns of a grocery business
- Identify top-performing products and customers
- Visualize category-wise contributions
- Estimate profits and profit margins using engineered features

---

## 📁 Dataset Overview

- Source: Provided Excel file with **6 sheets**
  - `Sales`, `Products`, `Categories`, `Customers`, `Cities`, `Countries`
- ~1,000 total sales transactions
- Not publicly shared due to source restrictions

---

## 🛠️ Tools & Libraries Used

- Python (Pandas, NumPy)
- Data Visualization: Matplotlib, Seaborn
- Environment: Jupyter Notebook

---

## 🔧 Key Steps in the Project

### 1. Data Loading & Cleaning
- Imported data from all Excel sheets
- Cleaned missing values and removed redundant columns
- Merged datasets using IDs to form a unified DataFrame

### 2. Feature Engineering
- `EstimatedCost` = Sales / 1.3 (based on assumed 30% markup)
- `EstimatedProfit` = Sales − EstimatedCost
- `ProfitMargin` = EstimatedProfit / Sales
- `IsDiscounted` = Discount > 0

### 3. Exploratory Data Analysis (EDA)
- Sales distribution by product and category
- Top customers by total purchase amount
- Profit vs sales visualizations
- Analysis of discount impact on sales

---

## 📊 Key Business Insights

- **Top 5 products** contributed significantly to overall revenue
- High-profit categories didn't always generate the highest sales
- Some customers and cities consistently generated higher revenue
- Discounts did not always result in higher quantities sold

---

## ✅ Conclusion

This project demonstrates:
- End-to-end data analysis workflow using real-world business data
- Ability to clean, merge, and enrich data with meaningful features
- Proficiency in extracting actionable insights from sales data

---

## 📈 Future Enhancements

- Add time-series analysis for monthly/seasonal trends
- Implement customer segmentation using clustering
- Build interactive dashboards using **Plotly Dash** or **Streamlit**

---

## 📂 Project Structure




```python

```
